/*
 * Somme.java                                                         02/10/2019
 */
package lyon1.l3info.lif13.somme;

/**
 * Somme les N premiers entiers et affiche le résultat en sortie console. 
 * 
 * @author julien.lacombe
 */
public class Somme {
    public static void main(String[] args) {
        int nbEntiers = Integer.parseInt(args[0]);
        int somme = 0;
        
        for (int i = 1; i <= nbEntiers; ++i) {
            somme += i;
        }
        
        System.out.println("La somme des " + nbEntiers 
                         + " premiers entiers est : " + somme);
    }
}
