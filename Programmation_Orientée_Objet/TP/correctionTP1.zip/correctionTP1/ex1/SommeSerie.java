/*
 * SommeSerie.java                                                    02/10/2019
 */
package lyon1.l3info.lif13.sommeserie;

/**
 * Somme les N premiers termes de la série 1 + 1/2 + 1/3 + 1/4 + ... + 1/N 
 * et affiche le résultat en sortie console. 
 * 
 * @author julien.lacombe
 */
public class SommeSerie {
    public static void main(String[] args) {
        int nbTermes = Integer.parseInt(args[0]);
        double somme = 0.;
        
        for (int i = 1; i <= nbTermes; ++i) {
            somme += 1. / ((double) i);
        }
        
        System.out.println("La somme des " + nbTermes 
                         + " premiers termes de la série est : " + somme);
    }
}
